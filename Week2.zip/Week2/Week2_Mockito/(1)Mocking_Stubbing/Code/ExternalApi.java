package com.ankitasingh.mock;
public interface ExternalApi {
    String getData();
}
