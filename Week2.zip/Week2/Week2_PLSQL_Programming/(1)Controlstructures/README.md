Exercise 1: Control Structures
Scenario 1: The bank wants to apply a discount to loan interest rates for customers above 60 years old.

  o	Question: Write a PL/SQL block that loops through all customers, checks their age, and if they are above 60, apply a 1% discount to their current loan interest rates.
Scenario 2: A customer can be promoted to VIP status based on their balance.

  o	Question: Write a PL/SQL block that iterates through all customers and sets a flag IsVIP to TRUE for those with a balance over $10,000.
Scenario 3: The bank wants to send reminders to customers whose loans are due within the next 30 days.

  o	Question: Write a PL/SQL block that fetches all loans due in the next 30 days and prints a reminder message for each customer.
